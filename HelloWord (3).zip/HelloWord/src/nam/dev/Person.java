package nam.dev;

public class Person {
	String name;
	private int age;
	
	public Person(String name) {
		this.name = name;
	}

	public Person(int age) {
		this.age = age;
	}

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public int getAge() {
		if(age < 1) age = 1;
		return age;
	}

}