package nam.dev;

public class Student extends Person{
	public Student(String name, int age) {
		super(name, age);
		// TODO Auto-generated constructor stub
		System.out.println("Ten: "+ name +  ". Tuoi: " + age); 
	}
}
