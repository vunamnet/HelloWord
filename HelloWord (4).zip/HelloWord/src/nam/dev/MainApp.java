package nam.dev;

import java.util.Scanner;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Scanner sc = new Scanner(System.in); System.out.println("Nhap ho va ten:");
		 * String fullName = sc.nextLine(); System.out.println("Ten ban: " + fullName);
		 * System.out.println("Nhap tuoi"); int age = sc.nextInt();
		 * System.out.println("Tuoi: " + age); System.out.println("So diem:"); double
		 * dtb = sc.nextDouble(); System.out.println("Diem trung binh: " + dtb);
		 * System.out.println("Ten ban: " + fullName + " - Tuoi: " + age + " - Diem: " +
		 * dtb); System.out.format("Ten ban: %s - Tuoi: %d - Diem %.2f", fullName, age,
		 * dtb).println();
		 */

		// ===== Bai 8 =====
		/*
		 * Scanner sc = new Scanner(System.in); System.out.println("Nhap so nguyen a:");
		 * int a = sc.nextInt(); System.out.println("a: " + a);
		 * 
		 * System.out.println("Nhap so nguyen b:"); int b = sc.nextInt();
		 * System.out.println("b: " + b);
		 * 
		 * float tong = a + b; System.out.format("Tong: %.2f", tong).println();
		 * 
		 * float hieu = a - b; System.out.format("Hieu: %.2f", hieu).println();
		 * 
		 * float nhan = a * b; System.out.format("Tich: %.2f", nhan).println();
		 * 
		 * float chia = (float) a / b; System.out.format("Thuong: %.2f",
		 * chia).println();
		 * 
		 * int c = 9; System.out.format("So nguyen c: %d", c).println();
		 * 
		 * boolean ketqua = (c > a) ? true : false; System.out.println("Ket qua c > a: "
		 * + ketqua);
		 * 
		 * ketqua = (c < a) ? true : false; System.out.println("Ket qua c < a: " +
		 * ketqua);
		 * 
		 * ketqua = (c >= a) ? true : false; System.out.println("Ket qua c >= a: " +
		 * ketqua);
		 * 
		 * ketqua = (c <= a ) ? true : false; System.out.println("Ket qua c <= a: " +
		 * ketqua);
		 */

		// ===== Bai 9.1 =====
		/*
		 * Scanner sc = new Scanner(System.in); System.out.println("Nhap so nguyen:");
		 * int a = sc.nextInt(); System.out.println("So nguyen: " + a); if (a > 0) {
		 * System.out.println("a la so nguyen duong"); } else if (a == 0) {
		 * System.out.println("a la so nguyen khong duong khong am"); } else {
		 * System.out.println("a la so nguyen am"); }
		 */

		// ===== Bai 9.2 =====
		/*
		 * Scanner sc = new Scanner(System.in); System.out.println("Nhap so nguyen:");
		 * int a = sc.nextInt(); System.out.println("So nguyen: " + a); if (a%3 == 0 &&
		 * a%5 == 0) { System.out.println("a chia het cho 3 va 5"); } else if (a%3 == 0)
		 * { System.out.println("a chia het cho 3"); } else if (a%5 == 0) {
		 * System.out.println("a chia het cho 5"); } else {
		 * System.out.println("a khong chia het cho 3 và cho 5"); }
		 */

		/*
		 * int i = 2, j = 1, tich = 0; while (i<=9) { j = 1; while (j<=10) { tich = i *
		 * j; System.out.print(j + "x" + i + "=" + tich + "\t"); j++; } i++;
		 * System.out.println(); }
		 */

		// Baif 11
		/*
		 * Scanner sc = new Scanner(System.in); System.out.println("Nhap so nguyen:");
		 * int n = sc.nextInt(); System.out.println("So nguyen: " + n); int i = 0, tong
		 * = 0; while (i <= n) { if (i%3 == 0) tong += i; i++; }
		 * System.out.println("Tong: " + tong);
		 */

		// For Loop
		/*
		 * Scanner sc = new Scanner(System.in); System.out.println("Nhap so nguyen:");
		 * int n = sc.nextInt(); System.out.println("So nguyen: " + n); int sobandau =
		 * 0, sodu = 0, socuoicung = 0; sobandau = n; while (n > 0) { // lay chu so cuoi
		 * sodu = n % 10; n = n / 10; socuoicung = socuoicung * 10 + sodu; } if
		 * (sobandau == socuoicung) { System.out.println("Ket qua: " + socuoicung +
		 * " polinum"); } else { System.out.println("Ket qua: " + socuoicung +
		 * " khong phai polinum"); }
		 * 
		 * // Mnagr 1 chiều // Bài 13 //Tao mang int arr[] = new int[10]; int n = 0;
		 * Scanner sc = new Scanner(System.in); while (n < 10) {
		 * System.out.println("Nhap phan tu thu:" + (n + 1)); arr[n] = sc.nextInt();
		 * n++; } //Tinh tong cac phan tu int sumArr = 0; for(int i = 0; i <arr.length;
		 * i++) { sumArr = sumArr + arr[i]; } System.out.println("Tong phan tu:" +
		 * sumArr); //Kiem tra chan le\ if (sumArr%2 == 0) {
		 * System.out.println("So tong la so chan"); } else {
		 * System.out.println("So tong la so le"); } //Kiem tra co bao nhieu phan tu
		 * chan, le int sumChan = 0, sumLe = 0; for(int i = 0; i <arr.length; i++) { if
		 * (arr[i]%2 == 0) { sumChan++; } else { sumLe++; } }
		 * System.out.println("Tong chan: " + sumChan + ". Tong le: " + sumLe); //Sap
		 * xep tang dan int soMin = 0; int arrTang[] = new int [arr.length]; for(int i =
		 * 0; i <arrTang.length; i++) { for(int j = 0; j < arr.length; j++) { if (arr[j]
		 * <= soMin) { arrTang[i] = arr[j]; soMin = arr[j]; break; } } } for(int k = 0;
		 * k <arrTang.length; k++) { System.out.println("Tang dan: " + arrTang[k]);
		 * 
		 * }
		 */

		// ===== Gọi Class ======
//		Person p = new Person();
//		p.name = "Thang1";
//		p.age = 30;
//		System.out.println("Ten 1:" + p.name + ". tuoi: " + p.age);

//		Person p2 = new Person();
//		p2.name = "Duong";
//		p2.age = 60;
//		System.out.println("Ten 2:" + p2.name + ". tuoi: " + p2.age);
		
		
		/*Person p;
		p  = new Person();
		p.name = "Thang";
		p.age = 30;
		System.out.println("Ten 1:" + p.name + ". tuoi: " + p.age);

		Person p2 = p; //Dùng chung đối tượng p
		p2.name = "Duong";
		p2.age = 60;
		System.out.println("Tuoi: " + p.age);
		System.out.println("Tuoi: " + p2.age);
		*/
		
		//===== Contructor =====
//		Person p = new Person("Hung");
//		System.out.println("Ten: " + p.name);
//		
//		p = new Person(30);
//		System.out.println("Tuoi: " + p.age);
//		
//		p = new Person("Hung", 30);
//		System.out.println("Ten: " + p.name + ". tuoi: " + p.age); 
		
		//Ham setter, getter
		/*Person p = new Person("Hung");
		p.setAge(30);
		System.out.println("Ten: " + p.name + ". tuoi: " + p.getAge()); 
		*/
		
		Student std = new Student("Hoang",30);
		
		
		
	}
}
