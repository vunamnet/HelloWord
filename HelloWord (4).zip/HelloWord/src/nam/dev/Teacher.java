package nam.dev;

public class Teacher extends Person{
	public Teacher(int age) {
		super(age);
		// TODO Auto-generated constructor stub
	}
	double hsl;
}


